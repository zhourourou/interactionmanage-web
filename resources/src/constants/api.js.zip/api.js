// const getApi = (url) => `${window.config.context}/${url}.jhtml`;
const getApi = (url) => `${window.config.context}/interactionmanage/v2/${url}`;

export const HOST_BASE = `${location.protocol}//${location.host}`;

export const CODE_STATUS_OK = 0;
export const CODE_UNAUTHORIZED = 401;


// 获取登录验证码
export const CODE_IMG = 'http://t.cn/R8MNl4Z'

//新增用户
export const NEW_USER = getApi('user/user')
// 用户登入
export const USER_LOGIN = getApi('user/login');
export const VERIFICATION = getApi('user/msg-code');

// 修改密码
export const UPDATE_PASSWORD = getApi('user/password');

//评论用户黑名单

export const COMMENT_BLACK_USER = getApi('comment/black-user');

//评论节目黑名单

export const COMMENT_BLACK_PROGRAM = getApi('comment/black-program');

//评论敏感词

export const COMMENT_SENSUTIVE_WORD = getApi('comment/sensitive-word');

//新增点赞次数
export const ADD_TIMES = getApi('/times');

//查询父评论的列表

export const QUERY_ANSWER_LISTS = getApi('base/queryParentList');

//根据评论ID删除父评论

export const DEL_ANSWER_ONE = getApi('base/deleteParentComment');

//根据评论ID置顶父/子评论

export const MAKE_ANSWER_TOP = getApi('base/topCommentYes');

//根据评论ID取消评论置顶
export const MAKE_ANSWER_NO = getApi('base/topCommentNo');

//新增评论点赞数

export const ADD_START_NUM = getApi('userLike/times');

//新增子评论

export const ADD_SON_ANSWER = getApi('base/addChildInfo');

//查询子评论
export const QUERY_CHILD_ANSWERLISTS = getApi('base/queryChildList');

//根据评论ID删除评论子评论
export const DEL_CHILD_ANSWER = getApi('base/deleteChildComment');

//查询子评论列表
export const QUERY_CHILD_LIST = getApi("base/queryChildList");

//导入子评论
export const IMPORT_EXCEL = getApi('comment/import/0');

//导出子评论
export const EXPORT_EXCEL = getApi('comment/export/0');

//导入父评论
export const FATHER_IMPORT_EXCEL = getApi('comment/import/1');

//导出父评论
export const FATHER_EXPORT_EXCEL = getApi('comment/export/1');






